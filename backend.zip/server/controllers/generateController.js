import OpenAI from 'openai';

export const generateController = async (req, res) => {
  // Security Check
  if (!process.env.OPENAI_API_KEY) {
    console.error("[Server] Missing OPENAI_API_KEY");
    return res.status(500).json({ 
      success: false, 
      message: "Server configuration error: AI Key missing." 
    });
  }

  const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
  });

  try {
    const { toolId, inputs } = req.body;

    // --- SYSTEM PROMPT ---
    const systemInstruction = `
      You are Script Video AI, a professional YouTube strategy engine.
      
      STRICT OUTPUT RULES:
      1. Return ONLY valid JSON.
      2. No Markdown formatting (\`\`\`json).
      3. No conversational text.
      
      SCHEMAS:
      - Lists: { "items": ["Item 1", "Item 2"] }
      - Structured: { "sections": [{ "heading": "Title", "content": "Body", "items": [] }] }
    `;

    // --- PROMPT ENGINEERING ---
    let userPrompt = "";
    switch (toolId) {
      case 'yt-hook':
        userPrompt = `Generate 10 viral hooks for: "${inputs.topic}". Focus on curiosity gaps. Return { "items": [...] }`;
        break;
      case 'yt-title':
        userPrompt = `Generate 15 high-CTR titles for: "${inputs.topic}". Use emotional triggers. Return { "items": [...] }`;
        break;
      case 'yt-breakdown':
        userPrompt = `Analyze strategy for: "${inputs.url || inputs.topic}". Sections: Hook, Retention, CTA. Return { "sections": [...] }`;
        break;
      case 'yt-keyword':
        userPrompt = `SEO keywords for: "${inputs.topic}". Group by Volume/Competition. Return { "sections": [...] }`;
        break;
      case 'strat-plan':
        userPrompt = `30-day growth plan for "${inputs.niche}" channel with goal "${inputs.goal}". Return { "sections": [...] }`;
        break;
      case 'strat-ideas':
        userPrompt = `20 viral video concepts for "${inputs.niche}". Return { "items": [...] }`;
        break;
      default:
        userPrompt = `Generate JSON content for tool "${toolId}" with inputs: ${JSON.stringify(inputs)}`;
    }

    // --- AI EXECUTION ---
    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: systemInstruction },
        { role: "user", content: userPrompt }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
      max_tokens: 1500,
    });

    const aiContent = completion.choices[0].message.content;

    if (!aiContent) throw new Error("Empty response from AI");

    // JSON Validation
    let jsonResponse;
    try {
      jsonResponse = JSON.parse(aiContent);
    } catch (e) {
      throw new Error("AI returned malformed JSON");
    }

    return res.status(200).json(jsonResponse);

  } catch (error) {
    console.error("[AI Error]", error);
    return res.status(500).json({ 
      success: false, 
      message: "AI Engine busy. Please try again.",
      error: error.message 
    });
  }
};